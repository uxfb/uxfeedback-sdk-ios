//
//  UXFeedbackSDK.h
//  UXFeedbackSDK
//
//  Created by Dmitry Kudryavtsev on 09/05/2019.
//  Copyright © 2019 UXF. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "YYImage.h"

//! Project version number for UXFeedbackSDK.
FOUNDATION_EXPORT double UXFeedbackSDKVersionNumber;

//! Project version string for UXFeedbackSDK.
FOUNDATION_EXPORT const unsigned char UXFeedbackSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UXFeedbackSDK/PublicHeader.h>


